const FOOTER_BANNER_HTML = 
    '<ins class="adsbygoogle"'
        + ' style="display:inline-block;width:100%;height:50px"'
        + ' data-ad-client="ca-pub-3423367744172781"'
        + ' data-ad-slot="7485414529"'
        + '>'
    + '</ins>';

window.HUHU = {};

// 定义 isOnline 变量
let isOnline = false;

// 检测初始网络状态
function checkNetworkStatus() {
    isOnline = navigator.onLine;
    isOnline = false;
    console.log(isOnline);
}

// 初始检测
checkNetworkStatus();

// 监听网络状态变化
window.addEventListener('online', checkNetworkStatus);
window.addEventListener('offline', checkNetworkStatus);

var MiAds = {
    start: function () {
        console.info("[MiAds.start] ...");

        window.addEventListener('resize', MiAds.correctPositions);
    },
    showGame: function () {
        console.info('[MiAds.showGame]');
    },
    showPreroll: function() {
        console.info("[MiAds.showPreroll] ... ");
        if (!isOnline) {
            console.log("[MiAds.showPreroll] No internet connection.");
            return;
        }

        adBreak({
            type: 'preroll',
            name: 'preroll',
            adBreakDone: (placementInfo) => {
                console.log("[MiAds.showPreroll] adBreakDone ... breakStatus=" + placementInfo.breakStatus);
                MiAds.showGame();
            }
        });

        window.addEventListener('resize', MiAds.correctPositions);
    },
    showInterstitial: function() {
        console.info("[MiAds.showInterstitial] ... ");

        if (!isOnline) {
            console.log("[MiAds.showInterstitial] No internet connection.");
            return;
        }

        adBreak({
            type: 'preroll',
            name: 'new_afg',
            adBreakDone: (placementInfo) => {
                console.log("[MiAds.showInterstitial] adBreakDone ... breakStatus=" + placementInfo.breakStatus);
                MiAds.showGame();
            }
        });

        window.addEventListener('resize', MiAds.correctPositions);
    },
    showReward: function() {
        console.info("[MiAds.showReward] ... ");

        if (!isOnline) {
            console.log("[MiAds.showReward] No internet connection.");
            if (typeof(window.HUHU._callback) == 'undefined') {
                return;
            }

            let _callback = window.HUHU._callback;
            if (_callback != null && typeof (_callback) == "function") {
                _callback();
                window.HUHU._callback = null;
            }
            return;
        }

        window.adsbygoogle = window.adsbygoogle || [];
        const adBreak = adConfig = function (o) {
            adsbygoogle.push(o);
        }

        adBreak({
            type: "reward",  // ad shows at start of next level
            name: "reward",
            beforeAd: () => {
                console.log('reward.beforeAd ' );
            },  // You may also want to mute the game's sound.
            afterAd: () => {
                console.log('reward.afterAd ');
            },
            adViewed: () => {
                console.log('reward.adViewed ');
            },
            beforeReward: (showAdFn) => {
                showAdFn();
            },
            adDismissed: () => {
                console.log('reward.adDismissed ');
            },
            adBreakDone: (placementInfo) => {
                console.log("reward.adBreakDone breakStatus=" + placementInfo.breakStatus);
                let breakStatus = placementInfo.breakStatus;

                if (breakStatus === "viewed") {
                    if (typeof(window.HUHU._callback) == 'undefined') {
                        return;
                    }

                    let _callback = window.HUHU._callback;
                    if (_callback != null && typeof (_callback) == "function") {
                        _callback();
                        window.HUHU._callback = null;
                    }
                }
                else {
                    if (typeof(window.HUHU._failback) == 'undefined') {
                        return;
                    }

                    let _failback = window.HUHU._failback;
                    if (_failback != null && typeof (_failback) != "function") {
                        console.log("Failed to pass fail callback");
                        return;
                    }

                    if (breakStatus === "frequencyCapped") {
                        _failback("Please wait for at least 30s to request ads again");
                    }
                    else if (breakStatus === "dismissed") {
                        _failback("Please watch ads until the end");
                    }
                    else {
                        _failback("Failed to load ads. Please wait for a while and try later.");
                    }

                    window.HUHU._failback = null;
                }
            }
        });

        window.addEventListener('resize', MiAds.correctPositions);
    },
};

function RandomNumBoth(Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    var num = Min + Math.round(Rand * Range);
    return num;
}

function _getWinWidth() {
    return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidt;
}

function _getWinHeight() {
    return window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
}

var _orientation = 'portrait';
var _checktime = 0;
var game_frame = document.getElementById('game_frame');
var gameframediv = document.getElementById('gameframediv');
var bannerStubHeight = 50;
var marginHeight = 10;

game_frame.src = "game.html" + window.location.search;

function resetGameFrameSize() {
    game_frame.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });
    game_frame.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });
    gameframediv.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });
    var _FrameWidth = document.documentElement.clientWidth;
    // var _FrameHeight = document.documentElement.clientHeight - bannerStubHeight - marginHeight;
    var _FrameHeight = document.documentElement.clientHeight;

    
    game_frame.style.width = _FrameWidth + "px";
    game_frame.style.height = _FrameHeight + "px";
    gameframediv.style.height = _FrameHeight + "px";
}

resetGameFrameSize();

function setSize() {
    var _w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    var _h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    _checktime = _checktime + 1;
    if (_checktime > 3)
        return;
    if (_orientation == 'landscape') {
        if (_w < _h) {
            setTimeout(setSize, 100);
            return;
        }
    } else {
        if (_w > _h) {
            setTimeout(setSize, 200);
            return;
        }
    }
    resetGameFrameSize();
}

function orient() {
    _checktime = 0;
    if (window.orientation == 0 || window.orientation == 180) {
        document.body.setAttribute('class', 'portrait');
        _orientation = 'portrait';
        setTimeout(setSize, 200);
        return false;
    } else if (window.orientation == 90 || window.orientation == -90) {
        document.body.setAttribute('class', 'landscape');
        _orientation = 'landscape';
        setTimeout(setSize, 200);
        return false;
    }
}

addEventListener('orientationchange', function (event) {
    orient();
});

function hidePreloader() {
    setTimeout(function () {
        var logoPreloader = document.getElementById('logo-preloader');
        logoPreloader.style.display = 'none';
    }, 1000);
}

let _MIN_INTERVAL = 30;
var _ts_start = Date.parse(new Date()) / 1000;

window.onmessage = function (e) {
    e = e || event;
    tempData = e.data + "";
    if (tempData == "splash") {
        // skip splash
        console.log("skip splash");
    }
    else if (tempData == "interstitial" || tempData == "open" || tempData == "next_level") {
        try {
            var currtime = Date.parse(new Date()) / 1000;
            var i = currtime - _ts_start;
            console.log("interval time = " + i);

            if (i >= _MIN_INTERVAL) {
                afg_ts_start = currtime;
                console.log("------------interstitial ad-------------");
                MiAds.showInterstitial();
            } 
            else {
                console.log("not meeting min interval: " + i + " / " + _MIN_INTERVAL + ', use reward instead');
                MiAds.showReward();
            }
        } catch (error) {
            console.log(error);
        }
    }
    else if (tempData == "reward") {
        MiAds.showReward();
    }
}

function addGoogleAnalytics() {
    if (!isOnline) {
        console.log("No internet connection, show game directly");
        return;
    }

    const head = document.getElementsByTagName("head")[0];

    var myScript = document.createElement("script");
    myScript.setAttribute("src", "https://www.googletagmanager.com/gtag/js?id=HMJB0M1KCD");
    myScript.async = true;
    myScript.onload = function () {
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());

        gtag("config", "G-HMJB0M1KCD");
        gtag("config", "G-SNJK7JXF70");
    };

    head.insertBefore(myScript, head.children[1]);
}

function appendFooterAds() {
    if (!isOnline) {
        console.log("[appendFooterAds] No internet connection.");
        return;
    }

    var bottomBannerElem = document.getElementById('bottom-banner');
    bottomBannerElem.style.top = (document.documentElement.clientHeight - bannerStubHeight) + "px";
    bottomBannerElem.style.height = bannerStubHeight + "px";
    bottomBannerElem.innerHTML = FOOTER_BANNER_HTML;

    var scriptElement = document.createElement("script");
    scriptElement.text = "(adsbygoogle = window.adsbygoogle || []).push({});";
    bottomBannerElem.appendChild(scriptElement);
}

function showRotateScreen() {
    if (typeof _force_horizontal === 'undefined' || _force_horizontal === false) {
        return;
    }

    let screenOrientation;
    if (window.innerWidth > window.innerHeight) {
        screenOrientation = "horizontal";
    } else {
        screenOrientation = "portrait";
    }

    var rotateElem =  document.getElementById("rotate");
    if (!rotateElem) {
        var rotateHtml = '<div id="rotate" class="rotate"><div class="icon"></div></div>';
        document.body.insertAdjacentHTML('beforeend', rotateHtml);
    }

    if (screenOrientation === "portrait") {
        // PORTRAIT
        document.getElementById("rotate").style.display = "block";
    }
    else {
        document.getElementById("rotate").style.display = "none";
    }
}

function _getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function loadScript(url, cb) {
    var script = document.createElement("script");
    function scriptLoaded() {
        document.body.removeChild(domScript);
        document.removeEventListener('load', scriptLoaded, false);
        cb && cb();
    };

    script.async = false;
    script.src = url;
    script.addEventListener('load', scriptLoaded, false);
}

function initializeAFGB(){
    console.log("[initializeAFGB] ...");

    if (!isOnline) {
        console.log("[initializeAFGB] No internet connection");
        return;
    }

    var adsenseScript = window.document.createElement("script");
    adsenseScript.setAttribute("src", "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js");
    adsenseScript.setAttribute("data-ad-client", "ca-pub-3423367744172781");
    adsenseScript.setAttribute("data-ad-frequency-hint", "30s");
    if (location.hostname.includes('127.0.0.1') || location.hostname.includes('localhost')) {
        adsenseScript.setAttribute("data-adbreak-test", "on");
    }

    window.document.head.appendChild(adsenseScript);
    
    window.adsbygoogle = window.adsbygoogle || [],
    window.adBreak = window.adConfig = function (e) {
        window.adsbygoogle.push(e)
    };
    
    adConfig({
        preloadAdBreaks: 'on',
        onReady: () => {
            console.log('[initializeAFGB] adConfig Ads Load Ready');
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    addGoogleAnalytics();
    hidePreloader();
    initializeAFGB();
    // appendFooterAds();
    showRotateScreen();
    window.addEventListener('resize', showRotateScreen);
});